#!/bin/bash

source scripts/docker.sh
source scripts/logging.sh
source scripts/environment.sh
source scripts/addorchestrationip.sh

# Enable debugging
#set -x

# Function to check if a command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

main() {

	# get conversation url
	unistall_digitalassistant
		
    echo "Unistallation complete."
}

main "$@"