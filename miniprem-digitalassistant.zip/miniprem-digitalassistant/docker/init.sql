CREATE SEQUENCE tenantid;
SELECT setval('tenantid', 10000);

CREATE SEQUENCE applicationid;
SELECT setval('applicationid', 10000);

CREATE SEQUENCE connectionid;
SELECT setval('connectionid', 10000);

CREATE SEQUENCE promptid;
SELECT setval('promptid', 10000);

CREATE SEQUENCE avatarid;
SELECT setval('avatarid', 10000);

CREATE SEQUENCE voiceid;
SELECT setval('voiceid', 10000);

CREATE SEQUENCE irsystemid;
SELECT setval('irsystemid', 10000);

CREATE SEQUENCE llmmodelid;
SELECT setval('llmmodelid', 10000);

CREATE SEQUENCE promptfilterid;
SELECT setval('promptfilterid', 10000);

CREATE SEQUENCE applicationrouteid;
SELECT setval('applicationrouteid', 10000);


CREATE TABLE public.tenant (
	tenant_id text PRIMARY KEY CHECK (tenant_id ~ '^T[0-9]+$' ) DEFAULT 'T' || nextval('tenantid'),
	env varchar NULL,
	tenant_address varchar NULL,
	tenant_email varchar NULL,
	tenant_name varchar NOT NULL,
	tenant_phone varchar NULL,
	created_at timestamp NOT NULL DEFAULT NOW(),
    updated_at timestamp NOT NULL DEFAULT NOW(),
    created_by varchar NULL ,
    updated_by varchar NULL,
	UNIQUE(tenant_name)
);

CREATE TABLE public.avatar (
	avatar_id text PRIMARY KEY CHECK (avatar_id ~ '^AV[0-9]+$' ) DEFAULT 'AV' || nextval('avatarid'),
	avatarname varchar NOT NULL,
	persona_id varchar NULL,
	description varchar NULL,
	avatar_style varchar NOT NULL,
	created_at timestamp NOT NULL DEFAULT NOW(),
    updated_at timestamp NOT NULL DEFAULT NOW(),
    created_by varchar NULL ,
    updated_by varchar NULL,
	synapse_enabled varchar NULL
);

CREATE TABLE public.application (
	application_id text PRIMARY KEY CHECK (application_id ~ '^A[0-9]+$' ) DEFAULT 'A' || nextval('applicationid'),
	application_name varchar NOT NULL,
	description varchar NULL,
	env varchar NULL,
	email1 varchar NULL,
	email2 varchar NULL,
	email_support varchar NULL,	
	email_owner varchar NULL,
	uneeq_persona_id varchar NULL,
	is_active varchar NULL,
	tenant_id varchar NOT NULL,
	created_at timestamp NOT NULL DEFAULT NOW(),
    updated_at timestamp NOT NULL DEFAULT NOW(),
    created_by varchar NULL ,
    updated_by varchar NULL,
	UNIQUE(application_name),
	constraint fk_application_tenantid foreign key (tenant_id) REFERENCES tenant (tenant_id) MATCH SIMPLE ON UPDATE NO ACTION ON DELETE NO ACTION
);

CREATE TABLE public.ir_system (
    ir_system_id text PRIMARY KEY CHECK (ir_system_id ~ '^IR[0-9]+$' ) DEFAULT 'IR' || nextval('irsystemid'),
    ir_system_name varchar NOT NULL,
    description varchar NOT NULL,
	created_at timestamp NOT NULL DEFAULT NOW(),
    updated_at timestamp NOT NULL DEFAULT NOW(),
    created_by varchar NULL ,
    updated_by varchar NULL,
    UNIQUE(ir_system_name)
);

CREATE TABLE public.llm_model (
    llm_model_id text PRIMARY KEY CHECK (llm_model_id ~ '^LLM[0-9]+$' ) DEFAULT 'LLM' || nextval('llmmodelid'),
    llm_model_name varchar NOT NULL,
    description varchar NOT NULL,
	created_at timestamp NOT NULL DEFAULT NOW(),
    updated_at timestamp NOT NULL DEFAULT NOW(),
    created_by varchar NULL ,
    updated_by varchar NULL,
    UNIQUE(llm_model_name)
);

	
CREATE TABLE public.prompt_filter (
    prompt_filter_id text PRIMARY KEY CHECK (prompt_filter_id ~ '^PF[0-9]+$' ) DEFAULT 'PF' || nextval('promptfilterid'),
    prompt_filter varchar NOT NULL,
	created_at timestamp NOT NULL DEFAULT NOW(),
    updated_at timestamp NOT NULL DEFAULT NOW(),
    created_by varchar NULL ,
    updated_by varchar NULL,
    UNIQUE(prompt_filter)
);

CREATE TABLE public.connection_info (
	connection_id text PRIMARY KEY CHECK (connection_id ~ '^C[0-9]+$' ) DEFAULT 'C' || nextval('connectionid'),
	is_default varchar NULL,
	application_id varchar NOT NULL,
	tenant_id varchar NOT NULL,
	audience varchar NULL,
	collection_id varchar NULL,
	endpoint_url varchar NULL,
	grant_type varchar NULL,
	client_secret varchar NULL,
	client_id varchar,
	oauth_token_url varchar NULL,
	created_at timestamp NOT NULL DEFAULT NOW(),
    updated_at timestamp NOT NULL DEFAULT NOW(),
    created_by varchar NULL ,
    updated_by varchar NULL,
	ir_system_id varchar NOT NULL,
	llm_model_id varchar NOT NULL,
	rasa_endpoint_url varchar NOT NULL,
	faiss_file varchar NOT NULL,
	pkl_file varchar NOT NULL,
	route varchar NOT NULL,
	file_names  character varying[],
	file_upload_status varchar NULL,
	UNIQUE(route),
    CONSTRAINT fk_connection_application FOREIGN KEY (application_id)
        REFERENCES public.application (application_id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT fk_connection_ir_system FOREIGN KEY (ir_system_id)
        REFERENCES public.ir_system (ir_system_id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT fk_connection_llm_model FOREIGN KEY (llm_model_id)
        REFERENCES public.llm_model (llm_model_id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT fk_connection_tenant FOREIGN KEY (tenant_id)
        REFERENCES public.tenant (tenant_id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
);


CREATE TABLE public.prompt_template_info (
	prompt_id text PRIMARY KEY CHECK (prompt_id ~ '^P[0-9]+$' ) DEFAULT 'P' || nextval('promptid'),
	env varchar NULL,
	promptName varchar NOT NULL,
	application_id varchar NOT NULL,
	tenant_id varchar NOT NULL,
	promptValue varchar NULL,
	answerValue varchar,
	is_default varchar NULL,
	created_at timestamp NOT NULL DEFAULT NOW(),
    updated_at timestamp NOT NULL DEFAULT NOW(),
    created_by varchar NULL ,
    updated_by varchar NULL,
	prompt_filter_id character varying[],
	route character varying,
	UNIQUE(promptName),
	CONSTRAINT fk_prompt_tenant FOREIGN KEY (tenant_id)
        REFERENCES public.tenant (tenant_id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
);


CREATE TABLE public.voice (
	voice_id text PRIMARY KEY CHECK (voice_id ~ '^VO[0-9]+$' ) DEFAULT 'VO' || nextval('voiceid'),
	voicename text UNIQUE,
	avatar_ids character varying[] NULL,
	voice_lang varchar NULL,
	pitch varchar NULL,
	prosody varchar NULL,
	description varchar NULL,
	created_at timestamp NOT NULL DEFAULT NOW(),
    updated_at timestamp NOT NULL DEFAULT NOW(),
    created_by varchar NULL ,
    updated_by varchar NULL
);


CREATE TABLE public.application_routes (
	applicationroute_id text PRIMARY KEY CHECK (applicationroute_id ~ '^AR[0-9]+$' ) DEFAULT 'AR' || nextval('applicationrouteid'),
	avatar_ids  character varying[],
	try_url_id UUID DEFAULT gen_random_uuid(),
	application_id varchar NOT NULL,
	route varchar NOT NULL,
	description varchar NULL,
	avatarvoice varchar NOT NULL,
	backgroundimageurL varchar NOT NULL,
	tenant_id varchar NOT NULL,
	welcome_message varchar NOT NULL,
	avatar_style varchar NOT NULL,
	pitch varchar NOT NULL,
	prosody varchar NOT NULL,
	created_at timestamp NOT NULL DEFAULT NOW(),
    updated_at timestamp NOT NULL DEFAULT NOW(),
    created_by varchar NULL ,
    updated_by varchar NULL,
	group_name varchar NULL,
	access_group varchar NULL,
	try_url_expiry_dt varchar NULL,
	n_ssml_max varchar NULL,
	default_lang varchar NULL,
	customers_email_addr varchar NULL,
	route_display_name varchar NULL,
	UNIQUE(route),
	CONSTRAINT fk_connection_application FOREIGN KEY (application_id)
		REFERENCES public.application (application_id) MATCH SIMPLE
		ON UPDATE NO ACTION
		ON DELETE NO ACTION,
	CONSTRAINT fk_connection_tenant FOREIGN KEY (tenant_id)
		REFERENCES public.tenant (tenant_id) MATCH SIMPLE
		ON UPDATE NO ACTION
		ON DELETE NO ACTION
);


CREATE TABLE public.dh_conversation_history
(
    _id UUID DEFAULT gen_random_uuid(),
    request_text jsonb,
    response_text jsonb,
	app_route_connection_info jsonb,
    application_name VARCHAR NULL,
    application_id VARCHAR NULL,
    created_dtm VARCHAR NULL,
    request_timestamp VARCHAR NULL,
    response_timestamp VARCHAR NULL,
    lang VARCHAR NULL,
    session_id VARCHAR NULL,
    request_context VARCHAR NULL,
    instance_name VARCHAR NULL,
    try_id VARCHAR NULL
);

INSERT INTO public.tenant(
	tenant_id, env, tenant_address, tenant_email, tenant_name, tenant_phone, created_by, updated_by)
	VALUES ('T10001', 'prod', 'One Dell Way', 'digitalhuman.scto@dell.com', 'Dell Internal Demo', '1234567890', 'digitalhuman.scto@dell.com', '');
	
INSERT INTO public.application(
	application_id, application_name, description, env, email1, email2, email_support, email_owner, uneeq_persona_id, is_active, tenant_id, created_by, updated_by)
	VALUES ('A10002','InternalDemo','Internal Demo','prod','digitalhuman.scto@dell.com','digitalhuman.scto@dell.com','digitalhuman.sct@dell.com','digitalhuman.scto@dell.com','2edf6996-f958-4ddb-a02e-4fd00d7b197','YES','T10001','digitalhuman.scto@dell.com','');
	

INSERT INTO avatar (avatar_id, avatarname, persona_id, description, avatar_style, created_by, updated_by, synapse_enabled) VALUES
('AV10001', 'Clara', 'b633ccd9-1cb1-4a77-ad65-a9716ea86e25', 'Dells First Digital Assistant', 'friendly','digitalhuman.scto@dell.com', 'digitalhuman.scto@dell.com', NULL),
('AV10003', 'Tomas', '2edf6996-f958-4ddb-a02e-4fdc00d7b197', 'Dell Digital Assistant', 'friendly', 'digitalhuman.scto@dell.com', 'digitalhuman.scto@dell.com', NULL),
('AV10004', 'AndiePolo', '60b2ca49-a416-49dd-961a-eb4819d20aaa', 'Dell Digital Assistant', 'friendly', 'digitalhuman.scto@dell.com', 'digitalhuman.scto@dell.com', NULL),
('AV10005', 'AndieScrubs', '4de23be3-0fd6-4a4f-8f0f-47a5bdbdaacd', 'Dell Digital Assistant', 'friendly',  'digitalhuman.scto@dell.com', NULL, NULL),
('AV10006', 'AndieBlouse', '8a6c311f-1416-40c8-9d87-583376a090db', 'Digital Assistant', 'friendly', 'digitalhuman.scto@dell.com', NULL, NULL),
('AV10008', 'AndieBlazer', '8e4543a9-34f7-4ab0-8f61-b00de62711ba', 'AndieBlazer', 'friendly', 'digitalhuman.scto@dell.com', NULL, NULL),
('AV10009', 'AndiePoloNvidia', '3fff1940-bd75-426c-b676-fd57e67fae0f', 'AndiePoloNvidia', 'friendly', 'digitalhuman.scto@dell.com', NULL, NULL),
('AV10010', 'Ethan', '45c5839d-ef14-4fda-b45c-ea9ee9afd308', 'Ethan ESG', 'friendly', 'digitalhuman.scto@dell.com', NULL, NULL),
('AV10011', 'MeiESG', 'cb4b4f03-707c-4f89-83ff-2e54070617d6', 'Mei ESG', 'friendly',  'digitalhuman.scto@dell.com', NULL, NULL),
('AV10012', 'Sara', 'ca91a119-596f-4a00-8d74-44bd224ff3e7', 'Sara ESG', 'friendly', 'digitalhuman.scto@dell.com', 'Biswajit_Saha1@Dell.com', NULL),
('AV10013', 'Andie Synapse', '1d4f9bf4-0311-4d78-b127-d096448d0841', 'Andie Synapse', 'friendly',  'digitalhuman.scto@dell.com', 'Biswajit_Saha1@Dell.com', 'Yes');
	

INSERT INTO prompt_filter (prompt_filter_id, prompt_filter, created_by, updated_by) VALUES
('PF10001', 'Any Negative Topic about Dell', 'digitalhuman.scto@dell.com', NULL),
('PF10002', 'Dell Competitors', 'digitalhuman.scto@dell.com', NULL),
('PF10003', 'Non-Dell devices or products', 'digitalhuman.scto@dell.com', NULL),
('PF10004', 'Dell Bugs or Problems', 'digitalhuman.scto@dell.com', NULL),
('PF10005', 'Geopolitical Topics', 'digitalhuman.scto@dell.com', NULL),
('PF10006', 'Jokes or Humor', 'digitalhuman.scto@dell.com', NULL),
('PF10007', 'Religion', 'digitalhuman.scto@dell.com', NULL),
('PF10008', 'Politics', 'digitalhuman.scto@dell.com', NULL),
('PF10009', 'Math questions', 'digitalhuman.scto@dell.com', NULL),
('PF10010', 'Holiday Information', 'digitalhuman.scto@dell.com', NULL),
('PF10011', 'Famous people and celebrities', 'digitalhuman.scto@dell.com', NULL),
('PF10012', 'Non-troubleshooting topics', 'digitalhuman.scto@dell.com', NULL);


INSERT INTO ir_system (ir_system_id, ir_system_name, description, created_by, updated_by) VALUES
('IR10001', 'Pryon', 'Pryon RAG', 'digitalhuman.scto@dell.com', NULL),
('IR10002', 'CTO IR FAISS DB GPU', 'CTO IR FAISS DB GPU', 'digitalhuman.scto@dell.com', NULL),
('IR10003', 'No IR', 'NO IR RAG', 'digitalhuman.scto@dell.com', NULL);

INSERT INTO llm_model (llm_model_id, llm_model_name, description, created_by, updated_by) VALUES
('LLM10001', 'OLLAMA-LLAMA3.18B', 'LLAMA3.1 8B Model', 'Satheeshkumar.Ramasamy@dell.com', NULL),
('LLM10002', 'openai-gpt3.5', 'openai-gpt3.5', 'Satheeshkumar.Ramasamy@dell.com', NULL),
('LLM10003', 'OLLAMA-phi3:mini', 'phi3:mini', 'Satheeshkumar.Ramasamy@dell.com', NULL),
('LLM10004', 'ollama-llama3.23b', 'phi3:mini', 'Satheeshkumar.Ramasamy@dell.com', NULL);


INSERT INTO voice (voice_id, voicename, description, created_by, updated_by, voice_lang, avatar_ids, pitch, prosody) VALUES
('VO10001', 'en-US-AvaNeural', 'Andie Voice', NULL, NULL, 'en-US', '{AV10005,AV10006,AV10004,AV10008,AV10009}', '-7.00%', '2.00%'),
('VO10002', 'en-US-JennyNeural', 'Clara Voice', NULL, NULL, 'en-US', '{AV10011,AV10012,AV10013,AV10001}', '-3.00%', '8.00%'),
('VO10004', 'es-ES-XimenaNeural', 'Spanish (Spain)', NULL, NULL, 'es-ES', '{AV10001,AV10005,AV10006,AV10004,AV10008,AV10009}', '-7.00%', '3.00%'),
('VO10005', 'fr-FR-VivienneMultilingualNeural', 'French (France)', NULL, NULL, 'fr-FR', '{AV10001,AV10005,AV10006,AV10004,AV10008,AV10009,AV10013}', '-1.00%', '-1.00%'),
('VO10006', 'ja-JP-ShioriNeural', 'Japanese (Japan)', NULL, NULL, 'ja-JP', '{AV10001,AV10005,AV10006,AV10004,AV10008,AV10009}', '-4.00%', '4.00%'),
('VO10007', 'de-DE-SeraphinaMultilingualNeural', 'German (Germany)', NULL, NULL, 'de-DE', '{AV10001,AV10005,AV10006,AV10004,AV10008,AV10009}', '-1.00%', '4.00%'),
('VO10008', 'ko-KR-SunHiNeural', 'Korean (Korea)', NULL, NULL, 'ko-KR', '{AV10001,AV10005,AV10006,AV10004,AV10008,AV10009}', '-2.00%', '4.00%'),
('VO10009', 'zh-HK-HiuGaaiNeural', 'Chinese (S)', NULL, NULL, 'zh-HK', '{AV10001,AV10005,AV10006,AV10004,AV10008,AV10009}', '-2.00%', '6.00%'),
('VO10010', 'it-IT-IsabellaNeural', 'Italian (Italy)', NULL, NULL, 'it-IT', '{AV10001,AV10005,AV10006,AV10004,AV10008,AV10009}', '-4.00%', '4.00%'),
('VO10011', 'pt-PT-FernandaNeural', 'Portuguese (Portugal)', NULL, NULL, 'pt-PT', '{AV10001,AV10005,AV10006,AV10004,AV10008,AV10009}', '-5.00%', '1.00%'),
('VO10012', 'nl-NL-ColetteNeural', 'Dutch (Netherlands)', NULL, NULL, 'nl-NL', '{AV10001,AV10005,AV10006,AV10004,AV10008,AV10009}', '-6.00%', '6.00%'),
('VO10013', 'sv-SE-HilleviNeural', 'Swedish (Sweden)', NULL, NULL, 'sv-SE', '{AV10001,AV10005,AV10006,AV10004,AV10008,AV10009}', '-7.00%', '6.00%'),
('VO10014', 'da-DK-ChristelNeural', 'Danish (Denmark)', NULL, NULL, 'da-DK', '{AV10001,AV10005,AV10006,AV10004,AV10008,AV10009}', '-2.00%', '6.00%'),
('VO10015', 'nb-NO-IselinNeural', 'Norwegian', NULL, NULL, 'nb-NO', '{AV10001,AV10005,AV10006,AV10004,AV10008,AV10009}', '-3.00%', '6.00%'),
('VO10016', 'ru-RU-DariyaNeural', 'Russian (Russia)', NULL, NULL, 'ru-RU', '{AV10001,AV10005,AV10006,AV10004,AV10008,AV10009}', '-4.00%', '3.00%'),
('VO10017', 'fi-FI-NooraNeural', 'Finnish (Finland)', NULL, NULL, 'fi-FI', '{AV10001,AV10005,AV10006,AV10004,AV10008,AV10009}', '-4.00%', '4.00%'),
('VO10018', 'pl-PL-ZofiaNeural', 'Polish (Poland)', NULL, NULL, 'pl-PL', '{AV10001,AV10005,AV10006,AV10004,AV10008,AV10009}', '-6.00%', '3.00%'),
('VO10019', 'tr-TR-EmelNeural', 'Turkish (Turkey)', NULL, NULL, 'tr-TR', '{AV10001,AV10005,AV10006,AV10004,AV10008,AV10009}', '-2.00%', '1.00%'),
('VO10020', 'ar-SA-ZariyahNeural', 'Arabic (Saudi Arabia)', NULL, NULL, 'ar-SA', '{AV10001,AV10005,AV10006,AV10004,AV10008,AV10009}', '-4.00%', '2.00%'),
('VO10021', 'ar-AE-FatimaNeural', 'Arabic (UAE)', NULL, NULL, 'ar-AE', '{AV10001,AV10005,AV10006,AV10004,AV10008,AV10009}', '-2.00%', '6.00%'),
('VO10022', 'th-TH-AcharaNeural', 'Thai (Thailand)', NULL, NULL, 'th-TH', '{AV10001,AV10005,AV10006,AV10004,AV10008,AV10009}', '-3.00%', '2.00%'),
('VO10023', 'id-ID-GadisNeural', 'Indonesian (Indonesia)', NULL, NULL, 'id-ID', '{AV10001,AV10005,AV10006,AV10004,AV10008,AV10009}', '-8.00%', '1.00%'),
('VO10024', 'cs-CZ-VlastaNeural', 'Czech (Czech Republic)', NULL, NULL, 'cs-CZ', '{AV10001,AV10005,AV10006,AV10004,AV10008,AV10009}', '-2.00%', '3.00%'),
('VO10025', 'hu-HU-NoemiNeural', 'Hungarian (Hungary)', NULL, NULL, 'hu-HU', '{AV10001,AV10005,AV10006,AV10004,AV10008,AV10009}', '-6.00%', '2.00%'),
('VO10026', 'ro-RO-AlinaNeural', 'Romanian (Romania)', NULL, NULL, 'ro-RO', '{AV10001,AV10005,AV10006,AV10004,AV10008,AV10009}', '2.00%', '2.00%'),
('VO10027', 'vi-VN-HoaiMyNeural', 'Vietnamese (Viet Nam)', NULL, NULL, 'vi-VN', '{AV10001,AV10005,AV10006,AV10004,AV10008,AV10009}', '-6.00%', '2.00%'),
('VO10028', 'hi-IN-SwaraNeural', 'Hindi (India)', NULL, NULL, 'hi-IN', '{AV10001,AV10005,AV10006,AV10004,AV10008,AV10009}', '-7.00%', '6.00%'),
('VO10041', 'en-CA-ClaraNeural', 'English Canada', NULL, NULL, 'en-CA', '{AV10001,AV10005,AV10006,AV10004,AV10008,AV10009,AV10011,AV10012}', '-3.00%', '6.00%'),
('VO10042', 'en-AU-NatashaNeural', 'English Australia', NULL, NULL, 'en-AU', '{AV10001,AV10005,AV10006,AV10004,AV10008,AV10009,AV10011,AV10012}', '-3.00%', '6.00%'),
('VO10043', 'en-IN-NeerjaNeural', 'English India', NULL, NULL, 'en-IN', '{AV10001,AV10005,AV10006,AV10004,AV10008,AV10009,AV10011,AV10012}', '-8.00%', '11.00%'),
('VO10045', 'en-GB-AbbiNeural', 'English United Kingdom', NULL, NULL, 'en-GB', '{AV10001,AV10005,AV10006,AV10004,AV10008,AV10009,AV10011,AV10012}', '-3.00%', '6.00%'),
('VO10046', 'en-IE-EmilyNeural', 'English Ireland', NULL, NULL, 'en-IE', '{AV10001,AV10005,AV10006,AV10004,AV10008,AV10009,AV10011,AV10012}', '-1.00%', '10.00%'),
('VO10047', 'en-SG-LunaNeural', 'English Singapore', NULL, NULL, 'en-SG', '{AV10005,AV10006,AV10004,AV10008,AV10009}', '3.00%', '-6.00%'),
('VO10048', 'en-US-AndrewNeural', 'Tomas AndrewNeural', 'Satheeshkumar.Ramasamy@dell.com', NULL, 'en-US', '{AV10003,AV10010}', '3.00%', '-6.00%'),
('VO10049', 'pt-BR-LeilaNeural', 'Portuguese (Brazil)', 'Satheeshkumar.Ramasamy@dell.com', NULL, 'pt-BR', '{AV10005,AV10006,AV10004,AV10008,AV10009,AV10013,AV10001}', '-7', '1');