#!/bin/bash

source scripts/docker.sh
source scripts/logging.sh
source scripts/environment.sh
source scripts/addorchestrationip.sh

# Enable debugging
#set -x

# Function to check if a command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

main() {

	# check docker installation
    check_docker_installation
	
	# pull the images down
    pull_docker_images

    # start the docker services
    start_docker_compose
	
	#addorchestrationip
	add_orchestrationip_to_hosts
	
	# get conversation url
	get_orchestration_ip_address
	
	#download_veritone_models
	download_veritone_models
		
    echo "Installation and configuration complete."
}

main "$@"