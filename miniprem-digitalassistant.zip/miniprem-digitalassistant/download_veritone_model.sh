#!/bin/bash

source scripts/docker.sh
source scripts/logging.sh
source scripts/environment.sh

# Enable debugging
#set -x

# Function to check if a command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

main() {

	# download_veritone_models
	download_veritone_models
		
    echo "Download veritone models completed."
}

main "$@"