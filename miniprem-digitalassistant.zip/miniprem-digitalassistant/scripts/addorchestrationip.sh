#!/bin/bash

# Define the IP address and hostname
IP="172.19.0.10"
HOSTNAME="digitalassistant-orchestration-api"
HOSTS_FILE="/etc/hosts"

add_orchestrationip_to_hosts() {
	# Check if the entry already exists in /etc/hosts
	if ! grep -q "$IP $HOSTNAME" "$HOSTS_FILE"; then
		# If not, add the entry to /etc/hosts
		echo "$IP $HOSTNAME" | sudo tee -a "$HOSTS_FILE" > /dev/null
		success "Entry added to /etc/hosts: $IP $HOSTNAME"
	else
		success "Entry already exists: $IP $HOSTNAME"
	fi
}