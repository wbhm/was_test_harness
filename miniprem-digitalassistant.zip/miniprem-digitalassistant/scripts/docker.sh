#!/bin/bash

# NOT TO BE RUN DIRECTLY, PLEASE RUN THE MAIN SCRIPT CALLED "install_miniprem_digitalassistant.sh"

check_docker_installed() {
    # Check if Docker is installed
    if ! command_exists docker; then
        warning 'Docker is not installed. Installing Docker...'

        # Prompt for sudo password
        sudo -v

        # Run commands with spinner
        {
            curl https://get.docker.com | sh && sudo systemctl --now enable docker
        } &
        show_spinner $!
        success "$CHECKMARK Docker & compose installed successfully."
    fi

    docker_version=$(docker --version | awk '{print $3}' | sed 's/,//')
    success "$CHECKMARK Docker version: $docker_version"
}


check_docker_installation() {
    log_section "Docker Prerequisites"

    check_docker_installed    
}

pull_docker_images() {
    log_section "Pulling Docker Images"

    # Pull Docker images
    info "Pulling Docker images, this make take some time..."

    # Prompt for sudo password
    sudo -v

    # Change to the docker directory
    cd docker > /dev/null 2>&1 || { fatal "$CROSS Failed to change directory to 'docker'"; }

    # Check if the user is already logged in
    if ! sudo docker info | grep -q "Username"; then
        # Prompt for Docker registry credentials
        read -p "Enter Docker registry username: " DOCKER_USERNAME
        read -s -p "Enter Docker registry password: " DOCKER_PASSWORD
        echo

        # Log in to the Docker registry
        sudo docker login -u "$DOCKER_USERNAME" -p "$DOCKER_PASSWORD"
        if [ $? -ne 0 ]; then
            fatal "$CROSS Failed to login to Docker registry."
        fi
    else
        info "Already logged in to Docker registry."
    fi

    {
        sudo docker compose -f docker-compose.yml pull
    } &
    show_spinner $!
    success "$CHECKMARK Docker images pulled successfully."

    cd - > /dev/null 2>&1 || { fatal "$CROSS Failed to change back to the original directory"; }
}

start_docker_compose() {
    log_section "Starting Docker Compose Services"

    # Prompt for sudo password
    sudo -v

    # Change to the docker directory
    cd docker > /dev/null 2>&1 || { fatal "$CROSS Failed to change directory to 'docker'"; }

    # Start Docker Compose services in detached mode
    info "Starting Docker Compose services..."
    sudo docker compose -f docker-compose.yml up -d
    if [ $? -ne 0 ]; then
        fatal "$CROSS Failed to start Docker Compose services."
    fi

    success "$CHECKMARK Docker Compose services started successfully."

    # Change back to the original directory
    cd - > /dev/null 2>&1 || { fatal "$CROSS Failed to change back to the original directory"; }
}

update_docker_compose_image() {
    local image_name=$1
    local compose_file="docker/docker-compose.yml"

    if [[ -f "$compose_file" ]]; then
        yq eval ".services.renny.image = \"$image_name\"" -i "$compose_file"
        success "$CHECKMARK Updated Docker image in $compose_file to $image_name"
    else
        fatal "$CROSS Docker compose file $compose_file not found."
    fi
}

# Function to read the current image value from the docker-compose.yml file
read_docker_compose_value() {
    local key=$1
    local compose_file="docker/docker-compose.yml"

    if [[ -f "$compose_file" ]]; then
        yq eval ".services.renny.$key" "$compose_file"
    else
        fatal "$CROSS Docker compose file $compose_file not found."
    fi
}


get_orchestration_ip_address(){
	# Get the IP address of the 'redis' container
	container_ip=$(sudo docker inspect --format '{{range .NetworkSettings.Networks}}{{.IPAddress}}{{end}}' digitalassistant-orchestration-api)

	# Check if the container IP address was found and print it
	if [ -z "$container_ip" ]; then
	  fatal "Container 'digitalassistant-orchestration-api' not found or has no IP address."
	else
	  # Construct the URL using the container's IP address
      url="http://${container_ip}:5000/p2/transcript"
	  success "Please configure the following URL as the conversation URL in your persona ID on the Uneeq admin portal.Additionally, ensure that the try id and apikey are added as headers.: $url or http://digitalassistant-orchestration-api:5000/p2/transcript"
	fi
}



download_veritone_models(){

	log_section "Downloading the veritone voice models"
	
	# Wait for 1 minute (60 seconds)
	echo "Waiting for 1 minute before sending the request to veritone container..."
	sleep 60
	
	# Wait for 1 minute (60 seconds)
	echo "Downloading the veritone models"
	
	# Define the URL
	URL="http://172.19.0.12:6600/models/refresh"

	# Define the Authorization Bearer Token
	AUTH_TOKEN="TEST"

	# Send the POST request using curl and capture the status code
	RESPONSE_CODE=$(curl --silent --location --request POST "$URL" \
	  --header "Authorization: Bearer $AUTH_TOKEN" \
	  --write-out "%{http_code}" --output /dev/null)

	# Print the response status code
	info "Response Code: $RESPONSE_CODE"

	# Check the response code and act accordingly
	if [ "$RESPONSE_CODE" -eq 200 ]; then
		success "Request was successful! Downloaded the veritone voice models"
	elif [ "$RESPONSE_CODE" -eq 401 ]; then
		echo "Unauthorized: Invalid or missing token."
	elif [ "$RESPONSE_CODE" -eq 404 ]; then
		echo "Error: Resource not found."
	elif [ "$RESPONSE_CODE" -eq 500 ]; then
		fatal "Internal Server Error.Failed to download the veritone voice models"
	else
		echo "Received unexpected response code: $RESPONSE_CODE"
	fi
	
	log_section "loading the veritone voice models"
	
	# Define the URL
	URL="http://172.19.0.12:6600/models/load"

	# Define the Authorization Bearer Token
	AUTH_TOKEN="TEST"
	
	# Define the JSON data
	JSON_DATA='{"model": "all"}'

	# Send the POST request using curl, capture the status code, and send the JSON data
	RESPONSE_CODE=$(curl --silent --location --request POST "$URL" \
	  --header "Authorization: Bearer $AUTH_TOKEN" \
	  --header "Content-Type: application/json" \
	  --data "$JSON_DATA" \
	  --write-out "%{http_code}" --output /dev/null)

	# Print the response status code
	info "Response Code: $RESPONSE_CODE"

	# Check the response code and act accordingly
	if [ "$RESPONSE_CODE" -eq 200 ]; then
		success "Request was successful! Loaded the veritone voice models"
	elif [ "$RESPONSE_CODE" -eq 401 ]; then
		echo "Unauthorized: Invalid or missing token."
	elif [ "$RESPONSE_CODE" -eq 404 ]; then
		echo "Error: Resource not found."
	elif [ "$RESPONSE_CODE" -eq 500 ]; then
		fatal "Internal Server Error.Failed to load the veritone voice models"
	else
		echo "Received unexpected response code: $RESPONSE_CODE"
	fi
}

unistall_digitalassistant(){
    log_section "Stopping Docker Compose Services"

    # Prompt for sudo password
	sudo -v

	# Change to the docker directory
	cd docker > /dev/null 2>&1 || { fatal "$CROSS Failed to change directory to 'docker'"; }

	# Start Docker Compose services in detached mode
	info "Starting Docker Compose services..."
	sudo docker compose -f docker-compose.yml down
	if [ $? -ne 0 ]; then
		fatal "$CROSS Failed to stop Docker Compose services."
	fi

	success "$CHECKMARK Docker Compose services stopped successfully."

	# Remove Docker images starting with "rsatkumar/digitalhuman*"
	info "Removing Docker images starting with 'rsatkumar/digitalhuman*'..."

	# List the image IDs starting with "rsatkumar/digitalhuman*"
	image_ids=$(sudo docker images --filter=reference='rsatkumar/digitalhuman*' -q)

	# Check if there are images to remove
	if [ -n "$image_ids" ]; then
		# Remove the images
		sudo docker rmi $image_ids
		if [ $? -ne 0 ]; then
			fatal "$CROSS Failed to remove Docker images."
		fi
		success "$CHECKMARK Docker images starting with 'rsatkumar/digitalhuman*' removed successfully."
	else
		info "No Docker images starting with 'rsatkumar/digitalhuman*' found."
	fi

	# Change back to the original directory
	cd - > /dev/null 2>&1 || { fatal "$CROSS Failed to change back to the original directory"; }	
}