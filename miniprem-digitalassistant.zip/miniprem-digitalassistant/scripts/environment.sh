#!/bin/bash

# NOT TO BE RUN DIRECTLY, PLEASE RUN THE MAIN SCRIPT CALLED "install_miniprem.sh"

# Function to read existing values from the .env file
read_env_variable() {
    local var_name=$1
    local env_file="docker/docker-compose.env"
    local value=""

    if [ -f "$env_file" ]; then
        value=$(grep "^$var_name=" "$env_file" | cut -d '=' -f 2-)
        value=$(echo $value | sed 's/^"//;s/"$//') # Remove surrounding quotes if any
    fi

    echo "$value"
}

# Function to update an environment variable in the .env file
update_env_variable() {
    local var_name=$1
    local new_value=$2
    local env_file="docker/docker-compose.env"

    if grep -q "^$var_name=" "$env_file"; then
        # Update the existing variable
        sed -i "s|^$var_name=.*|$var_name=$new_value|" "$env_file"
        #echo "Updated $var_name in $env_file"
    else
        # Add the variable if it does not exist
        echo "$var_name=$new_value" >> "$env_file"
        #echo "Added $var_name to $env_file"
    fi
}